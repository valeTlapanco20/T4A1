
package t4a1;
import java.util.Scanner;
public class T4A1 {

    
    public static void main(String[] args) {
   // ejercicio1();
    ejercicio2();
    }
    
    
    //EJERCICIO 1
    public static void ejercicio1(){
        
        Scanner scanner = new Scanner (System.in);
        
          int numero = 0;
          
          System.out.println("Hasta donde quieres llegar:");
          int limite =  scanner.nextInt();
          
          while (numero < limite) {
              numero++;
              System.out.println(numero);
          }
            
        }
    
    //EJERCICIO 2
    
    public static void ejercicio2(){
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Piezas a confeccionar: ");
        int npiezas =scanner.nextInt();
        int n = 0;
        int tallaM = 0;
        
        while (n < npiezas){
            n++;
            
            System.out.print("\nTalla:");
            String talla = scanner.next();
            
            if (talla.equals("s")|| talla.equals("S")){
                
            }else if (talla.equals("m")|| talla.equals("M")){
                tallaM++;
            }else if (talla.equals("l")|| talla.equals("L")){
                
            }else{
                
            }
            
            
            
            
        }
        System.out.print("Talla mediana:" + tallaM);
    }
    }
    

  
        